import { Injectable } from "@angular/core";
import { NewTaskData } from "./task/task.model";

@Injectable({ providedIn: 'root'})
export class TasksService {
    private tasks = [
        {
            id: 't1',
            userId: 'u1',
            title: 'Master Angular',
            summary: 'Learn all the basic and advanced features of Angular and how to apply them.',
            dueDate: '2025-12-31'
        },
        {
            id: 't2',
            userId: 'u3',
            title: 'Build a prototype',
            summary: 'Build a first prototype of the online shop website.',
            dueDate: '2024-5-31'
        },
        {
            id: 't3',
            userId: 'u3',
            title: 'Master Java',
            summary: 'Learn all the basic and advanced features of Java and how to apply them.',
            dueDate: '2024-06-15'
        }
    ]

    getUserTasks(userId: string) {
        return this.tasks.filter((task) => task.userId === userId);
    }

    addTasks(taskData: NewTaskData, userId: string) {
        this.tasks.push({
            id: new Date().getTime().toString(),
            userId: userId,
            title: taskData.title,
            summary: taskData.summary,
            dueDate: taskData.date
        })
    }

    deleteTask(id : string) {
        this.tasks = this.tasks.filter((task) => task.id != id);
    }
}