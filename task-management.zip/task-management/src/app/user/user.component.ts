import { Component, computed, Input, signal, input, Output, EventEmitter, output } from '@angular/core';
import { DUMMY_USERS } from '../dummy-users';
import { User } from './user.model';
import { CardComponent } from "../shared/card/card.component";

let randomIndex = Math.floor(Math.random() * DUMMY_USERS.length);

// typescript feature 

// type User = {
//   id : string;
//   avatar : string;
//   name : string;
// }

// interface User {
//   id : string;
//   avatar : string;
//   name : string;
// }

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [CardComponent],
  templateUrl: './user.component.html',
  styleUrl: './user.component.css'
})
export class UserComponent {

  // managing state and changing data
  // selectedUser = DUMMY_USERS[randomIndex];

  // Javascript and typescript feature
  // get imagePath() {
  //   return 'assets/users/' + this.selectedUser.avatar;
  // }


  // using signal for managing state and changing data 
  // selectedUser = signal(DUMMY_USERS[randomIndex]);

  // signal way of taking image path
  // imagePath = computed(() => 'assets/users/' + this.selectedUser().avatar)


  // managing state and changing data - zone.js is required for this - 
  // onSelectUser() {
  // randomIndex = Math.floor(Math.random() * DUMMY_USERS.length);

  // normal way
  // this.selectedUser = DUMMY_USERS[randomIndex];

  // signal way
  // this.selectedUser.set(DUMMY_USERS[randomIndex]);
  // }

  // @Input({required: true}) id!: string;
  // @Input({required: true}) avatar!: string;
  // @Input({required: true}) name!: string;
  @Input({ required: true }) user!: User;
  @Input({ required: true }) selected!: boolean;
  @Output() select = new EventEmitter();

  // signal way of doing output
  // select = output<string>();

  get imagePath() {
    // return 'assets/users/' + this.avatar;
    return 'assets/users/' + this.user.avatar;
  }

  // signal
  // avatar = input.required<string>();
  // name = input.required<string>();

  // imagePath = computed(() => {
  //   return 'assets/users/' + this.avatar();
  // })


  onSelectUser() {
    // this.select.emit(this.id)
    this.select.emit(this.user.id)
  }


}
