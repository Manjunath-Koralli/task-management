import { Component, DestroyRef, inject } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
  imports : [ReactiveFormsModule]
})
export class LoginComponent {

  private destroyRef = inject(DestroyRef); 

  form = new FormGroup({
    email : new FormControl('', {
      validators : [Validators.email, Validators.required]
    }),
    password : new FormControl('', {
      validators : [Validators.required, Validators.minLength(6)]
    })
  })

  get emailIsInvalid() {
    return (this.form.controls.email.touched 
      && this.form.controls.email.dirty 
      && this.form.controls.email.invalid);
  }

  get passwordIsInvalid() {
    return (this.form.controls.password.touched 
      && this.form.controls.password.dirty 
      && this.form.controls.password.invalid);
  }

  ngOnInit() {

    const savedForm = window.localStorage.getItem('saved-login-form');
    if(savedForm) {
      const formValue = JSON.parse(savedForm);
      // this.form.controls.email.setValue(formValue.email);

      // other controls stay untouched
      this.form.patchValue({
        email : formValue.email
      })
    }

    const subscription = this.form.valueChanges.subscribe({
      next : (value) => {
        window.localStorage.setItem('saved-login-form', JSON.stringify({ email : value.email}))
      }
    })

    this.destroyRef.onDestroy(() => subscription.unsubscribe());
  }

  onSubmit() {
    console.log(this.form)
    // this.form.controls.email
    // this.form.value.email
    const enteredEmail = this.form.value.email;
    const enteredPassword = this.form.value.password;
    console.log(enteredEmail, enteredPassword)
  }
}
