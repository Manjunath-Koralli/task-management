import { Component, contentChild, ContentChild, ElementRef, Input, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-control',
  standalone: true,
  imports: [],
  templateUrl: './control.component.html',
  styleUrl: './control.component.css',
  encapsulation: ViewEncapsulation.None,
  host : {
    '(click)' : 'onClick()' 
  }
})
export class ControlComponent {

  @Input({ required: true }) label! : string;

  // @ContentChild('contentInput') private control? : ElementRef<HTMLInputElement | HTMLTextAreaElement>;
  private control = contentChild<ElementRef<HTMLInputElement | HTMLTextAreaElement>>('contentInput');

  onClick() {
    console.log("Clicked");
    // console.log(this.control)
    console.log(this.control());
  }
}
