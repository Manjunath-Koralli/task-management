import { afterNextRender, afterRender, AfterViewInit, Component, ElementRef, EventEmitter, OnInit, Output, viewChild, ViewChild } from '@angular/core';
import { ButtonComponent } from '../../../shared/button/button.component';
import { ControlComponent } from "../../../shared/control/control.component";
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-new-ticket',
  standalone: true,
  imports: [ButtonComponent, ControlComponent, FormsModule],
  templateUrl: './new-ticket.component.html',
  styleUrl: './new-ticket.component.css'
})
export class NewTicketComponent implements OnInit,AfterViewInit {

  @Output() add = new EventEmitter<{title:string; text:string}>();

  // onSubmit(titleInputEle : HTMLInputElement, requestInputEle : HTMLTextAreaElement) {
  //   console.dir(titleInputEle);
  //   console.log(titleInputEle.value);
  //   const enteredTitle = titleInputEle.value;
  //   const enteredRequest = requestInput.value;
    
  // }

  // onSubmit(titleInput : string, requestInput : string, form : HTMLFormElement) {
  //   const enteredTitle = titleInput;
  //   const enteredRequest = requestInput;
  //   form.reset();
  // }

  // find elements in the component template
  @ViewChild('form') form?: ElementRef<HTMLFormElement>;
  // private form = viewChild.required<ElementRef<HTMLFormElement>>('form');

  onSubmit(titleInput : string, requestInput : string) {
    const enteredTitle = titleInput;
    const enteredRequest = requestInput;
    console.log(enteredTitle + " " + enteredRequest);
    this.add.emit({title : titleInput, text : requestInput})
    this.form?.nativeElement.reset();
    // this.form().nativeElement.reset();
  }

  ngOnInit()  {
    console.log("On init " + this.form?.nativeElement); //undefined
    // console.log("After view init " + this.form().nativeElement) // available
  }

  ngAfterViewInit()  {
    console.log("After view init " + this.form?.nativeElement)
    // console.log("After view init " + this.form().nativeElement)
  }

  constructor() {

    // runs everytime - when anything changes anywhere in entire application
    afterRender(() => {
      console.log("After render");
    });

    // runs once - when anything changes anywhere in entire application
    afterNextRender(() => {
      console.log("After next render");
    });
  }
}
