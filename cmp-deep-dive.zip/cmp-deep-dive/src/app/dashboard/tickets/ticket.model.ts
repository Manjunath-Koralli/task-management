export interface Ticket {
    id : string;
    title : string;
    request : string;
    status : 'open' | 'closed'; //union type of string literals
}